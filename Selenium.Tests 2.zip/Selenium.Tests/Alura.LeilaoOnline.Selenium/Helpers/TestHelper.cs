﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alura.LeilaoOnline.Selenium.Helpers
{
    public static class TestHelper
    {
      
    }
}
