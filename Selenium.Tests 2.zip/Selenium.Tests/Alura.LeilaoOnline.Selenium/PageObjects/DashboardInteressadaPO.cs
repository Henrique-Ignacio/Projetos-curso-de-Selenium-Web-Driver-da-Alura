﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Text;

namespace Alura.LeilaoOnline.Selenium.PageObjects
{
    public class DashboardInteressadaPO
    {
        private IWebDriver driver;
        private By ByLogoutLink;
        private By ByMeuPerfilLInk;
        public DashboardInteressadaPO(IWebDriver driver)
        {
            this.driver = driver;
            ByLogoutLink = By.Id("logout");
            ByMeuPerfilLInk = By.Id("meu-perfil");
        }

        public void EfetuarLogout()
        {
            var LinkLogout = driver.FindElement(ByLogoutLink);
            var LinkMeuPerfil = driver.FindElement(ByMeuPerfilLInk);

            IAction acaoLogout = new Actions(driver) 
                // mover para elemento pai
                .MoveToElement(LinkMeuPerfil)

                // mover para link de logout
                .MoveToElement(LinkLogout)

                // clicar no link de logout
                .Click()

                .Build();
            acaoLogout.Perform();
        }
    }
}
