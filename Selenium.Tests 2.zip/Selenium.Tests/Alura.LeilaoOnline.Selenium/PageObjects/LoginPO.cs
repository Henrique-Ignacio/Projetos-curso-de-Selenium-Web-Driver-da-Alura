﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace Alura.LeilaoOnline.Selenium.PageObjects
{
    public class LoginPO
    {
        private IWebDriver driver;
        private By ByInputLogin;
        private By ByInputSenha;
        private By ByBotaoLogin;


        public LoginPO(IWebDriver driver)
        {
            this.driver = driver;
            ByInputLogin = By.Id("Login");
            ByInputSenha = By.Id("Password");
            ByBotaoLogin = By.Id("btnLogin");
        }

        public void Visitar()
        {
            driver.Navigate().GoToUrl("http://localhost:51128/Autenticacao/Login");
        }

        public void PreencheFormulario (string login, string senha)
        {
            driver.FindElement(ByInputLogin).SendKeys(login);
            driver.FindElement(ByInputSenha).SendKeys(senha);
        }

        public void SubmeteFormulario()
        {
            driver.FindElement(ByBotaoLogin).Submit();
        }
    }
}
