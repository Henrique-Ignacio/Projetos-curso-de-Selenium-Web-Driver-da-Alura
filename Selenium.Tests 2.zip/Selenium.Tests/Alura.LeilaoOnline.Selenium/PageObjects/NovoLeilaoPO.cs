﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace Alura.LeilaoOnline.Selenium.PageObjects
{
    public class NovoLeilaoPO
    {

        private IWebDriver driver;
        private By byInputTitulo;
        private By byInputDescricao;
        private By byInputCategoria;
        private By byInputValorInicial;
        private By byInputImagem;
        private By byInputInicioPregao;
        private By byInputTerminoPregao;
        private By byBotaoSalvar;


        public NovoLeilaoPO(IWebDriver driver)
        {
            this.driver = driver;
            byInputTitulo = By.Id("Titulo");
            byInputDescricao = By.Id("Descricao");
            byInputCategoria = By.CssSelector("input.select-dropdown");
            byInputValorInicial = By.Id("ValorInicial");
            byInputImagem = By.Id("ArquivoImagem");
            byInputInicioPregao = By.Id("InicioPregao");
            byInputTerminoPregao = By.Id("TerminoPregao");
            byBotaoSalvar = By.CssSelector("button[type=submit]");
        } 
        public void Visitar()
        {
            driver.Navigate().GoToUrl("http://localhost:51128/Leiloes/Novo");
        }
        public void PreencheFormulario(
            string titulo,
            string descricao,
            string categoria,
            double valor,
            string imagem,
            DateTime inicio,
            DateTime termino )
        {
         driver.FindElement(byInputTitulo).SendKeys(titulo); Thread.Sleep(5000);

            driver.FindElement(byInputDescricao).SendKeys(descricao); Thread.Sleep(5000);

            SelecionarCategoria(categoria);

            driver.FindElement(byInputValorInicial).SendKeys(valor.ToString());
            Thread.Sleep(5000);

         driver.FindElement(byInputImagem).SendKeys(imagem);
            Thread.Sleep(5000);
            driver.FindElement(byInputInicioPregao).SendKeys(inicio.ToString("dd/MM/yyyy")); Thread.Sleep(5000);

            driver.FindElement(byInputTerminoPregao).SendKeys(termino.ToString("dd/MM/yyyy")); Thread.Sleep(5000);

        }

        public void SubmeteFormulario()
        {
            driver.FindElement(byBotaoSalvar).Click();
        }
        public IEnumerable<string> Categorias
        {            
            get
            {
                var campoCategoria = driver.FindElement(byInputCategoria);

                campoCategoria.Click();

                string dataTarget = campoCategoria.GetAttribute("data-target");

                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));

                var lista = wait.Until(d =>
                    d.FindElement(By.Id(dataTarget)));

                var opcoes = lista.FindElements(By.CssSelector("li span"));

                return opcoes.Select(o => o.Text);
            }
        }
        public void SelecionarCategoria(string categoria)
        {
            var campoCategoria = driver.FindElement(byInputCategoria);
            campoCategoria.Click();

            string dataTarget = campoCategoria.GetAttribute("data-target");

            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            var lista = wait.Until(driver =>
                driver.FindElement(By.Id(dataTarget)));

            // encontra o LI pelo texto
            var opcao = lista.FindElement(
                By.XPath($".//li/span[text()='{categoria}']")
            );

            opcao.Click();
        }


    }
}
